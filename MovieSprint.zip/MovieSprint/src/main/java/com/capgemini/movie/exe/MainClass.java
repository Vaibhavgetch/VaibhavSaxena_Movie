package com.capgemini.movie.exe;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Scanner;
import com.capgemini.movie.dto.Admin;
import com.capgemini.movie.dto.Theatre;
import com.capgemini.movie.services.*;

public class MainClass {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		
		  Storage.extractFile(); Scanner sc = new Scanner(System.in);
		  System.out.println("Welcome Admin . Enter Password to confrim :"); String
		  str1 = sc.nextLine() ;
		  
		  if(str1.equals("password")) {
		  
		  System.out.println("Verified !!!");
		  
		  Admin adm = new Admin("CS16086", "Vaibhav Saxena", "password", "25-01-1998",
		  "9876542") ; AdminServices ads = new AdminServices() ;
		  
		  System.out.println("WHAT DO YOU WANT TO DO :");
		  System.out.println(" 1.Add Thetre"); 
		  System.out.println(" 2.View Theatre");
		  System.out.println(" 3.Update Theatre");
		  System.out.println(" 4.Delete Theatre"); String str = sc.nextLine();
		  
		  if(str.charAt(0)=='1') {
		  System.out.println("Enter no. of theatres you want to add : "); int tn=
		  sc.nextInt() ; for (int i = 1; i <= tn; i++) { Theatre t = ads.addTheatre() ;
		  Storage.addTheatre(t);
		  System.out.println("        ################################      ");
		  
		  }
		  
		  } else if(str.charAt(0)=='2') {
		  
		      ads.viewMovies() ;
			  
		  }
		  
		  }
		  
		  System.out.println(Storage.getTheatrehs());
		  Storage.storeFile(Storage.getTheatrehs());
		 
		
		
		
		
	}
	
	

}
