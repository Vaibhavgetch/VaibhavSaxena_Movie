package com.capgemini.movie.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.capgemini.movie.dto.Theatre;

  public class Storage  {

	static HashMap<Integer, Theatre> theatrehs = new HashMap<Integer,Theatre> ();
	public static void storeFile(HashMap<Integer, Theatre> theatrehs) throws IOException {
		
		
		File f = new File("C:\\Users\\vaibh\\OneDrive\\Documents\\DataStorage\\MovieData.txt") ;
		FileOutputStream fos = new FileOutputStream(f) ;
		ObjectOutputStream oos = new ObjectOutputStream(fos) ;	
		oos.writeObject(theatrehs);
		oos.close();
		fos.close();
		System.out.println("Stored");
		
	}
	
	public static void extractFile() throws IOException, ClassNotFoundException {
		
		File f = new File("C:\\Users\\vaibh\\OneDrive\\Documents\\DataStorage\\MovieData.txt") ;
		FileInputStream fis = new FileInputStream(f) ;
		ObjectInputStream ois = new ObjectInputStream(fis) ;	
		
		theatrehs = (HashMap<Integer, Theatre>)ois.readObject() ;
		
		ois.close();
		fis.close();
		
	}
	static public void addTheatre(Theatre t) {
		theatrehs.put(t.getTheaterId(), t);
	}	
	
	
	
	 
	static public HashMap<Integer, Theatre> getTheatrehs() {
		return theatrehs;
	}

	
	 
	
}
