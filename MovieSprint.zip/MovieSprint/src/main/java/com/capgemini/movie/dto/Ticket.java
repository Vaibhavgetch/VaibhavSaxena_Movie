package com.capgemini.movie.dto;

public class Ticket extends Booking {
	
		private int ticketId ;
		int noOfSeats;
		seatName: String[*];
		Booking bookingRef; 
		boolean ticketStatus;
		String screenName;


}
