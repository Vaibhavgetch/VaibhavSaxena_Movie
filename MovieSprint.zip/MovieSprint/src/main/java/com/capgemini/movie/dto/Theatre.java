package com.capgemini.movie.dto;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Theatre implements Serializable {

	
	    int	theaterId;
		String theaterName;
		String theaterCity ; 
		String managerName;
		String managerContact ;
		
		String movie[] = new String[5] ;
		public String[] getMovie() {
			return movie;
		}
		public void setMovie(String[] m) {
			movie = m;
		}
		public int getTheaterId() {
			return theaterId;
		}
		public void setTheaterId(int theaterId) {
			this.theaterId = theaterId;
		}
		public String getTheaterName() {
			return theaterName;
		}
		public void setTheaterName(String theaterName) {
			this.theaterName = theaterName;
		}
		public String getTheaterCity() {
			return theaterCity;
		}
		public void setTheaterCity(String theaterCity) {
			this.theaterCity = theaterCity;
		}
		
		
		
		public String getManagerName() {
			return managerName;
		}
		public void setManagerName(String managerName) {
			this.managerName = managerName;
		}
		public String getManagerContact() {
			return managerContact;
		}
		public void setManagerContact(String managerContact) {
			this.managerContact = managerContact;
		}
		@Override
		public String toString() {
			return "Theatre [theaterId=" +theaterId + "\n" +" theaterName=" + theaterName +"\n" + ", theaterCity=" +"\n" + theaterCity
					+"\n" + ", managerName=" +"\n" + managerName +"\n" + " managerContact=" +"\n" + managerContact + "\n" +", movie="
					+ Arrays.toString(movie) + "]";
		}
		
		
		
		
		

}
