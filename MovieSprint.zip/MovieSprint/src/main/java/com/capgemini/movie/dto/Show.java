package com.capgemini.movie.dto;

import java.sql.Time;

public class Show {
	
		int showId;
		Time showStartTime;
		Time showEndTime;
		seats: Seat[*];
		String showName;
		Movie movieName; 
		
		


}
