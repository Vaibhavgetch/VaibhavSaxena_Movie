package com.capgemini.movie.services;

import java.util.*;


import com.capgemini.movie.dto.Theatre;

public class AdminServices {
	
	Scanner sc = new Scanner(System.in) ;
	
	public Theatre addTheatre() {
		
		
		Theatre the = new Theatre();
		
		System.out.println("-----Enter Theatre ID------");
		the.setTheaterId(sc.nextInt());
		sc.nextLine();
		
		System.out.println("-------Enter Theatre Name------");
		the.setTheaterName(sc.nextLine());
		
		System.out.println("-------Enter Theatre City------");
		the.setTheaterCity(sc.nextLine());
		
	
		System.out.println("-------Enter Manager Name------");
		the.setManagerName(sc.nextLine());
		
		System.out.println("-------Enter Manager Contact------");
		the.setManagerContact(sc.nextLine());
		
	      System.out.println("Enter Movie Details :  ");
	       String str[] = new String[5] ;
	   
	       System.out.println("------Enter Movie ID : ------");
		  str[0]=sc.nextLine() ;
		   
		 System.out.println("------Enter Movie Name ------");
		  str[1]=sc.nextLine() ;
		  
		   System.out.println("------Enter Movie Director ------");
		   str[2]=sc.nextLine() ;
		   
		   System.out.println("-------Enter Movie Length------");
		   str[3]=sc.nextLine() ;
		   
		   System.out.print("  minutes");
		   sc.nextLine();
		   
		   System.out.println("------Enter Movie Release Date------");
		   str[4]=sc.nextLine() ;
		   the.setMovie(str);
	     
		return the;
	
		
	}
	
	public void viewMovies() {
		
		HashMap<Integer,Theatre> hs = Storage.getTheatrehs();
		for(Theatre t : hs.values()) {
			 String[] str= t.getMovie() ;
			 for(int i = 0 ; i<5;i++) {
				 System.out.print(str[i]+" ");
			 }
			 System.out.println();
		}
		
		
		
	} 
	

}
