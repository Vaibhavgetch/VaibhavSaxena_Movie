package com.capgemini.movie.dto;

import java.time.LocalDate;

public class Booking {
	
		int bookingId;
		int movieId;
		int showId;
		Show showRef;
		LocalDate bookingDate; 
		int transactionId;
		double totalCost;
		seatList: Seat[*]
		Ticket ticket; 


}
